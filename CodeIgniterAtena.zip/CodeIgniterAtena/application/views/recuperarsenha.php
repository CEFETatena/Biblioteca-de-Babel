<html>
	<head>
		<meta charset="utf-8">
		<title>Biblioteca de Babel</title>	
	</head>
	<body>
		<h1>Biblioteca de Babel</h1>
		<h3>Recuperação de Senha</h3>
		<p>Olá, usuário!</p>
		<p>Clique no link para que possa redefinir sua senha: <a class="recuperarsenha" href="redefinirsenha">Clique aqui</a></p>
		<p>Se não fez essa solicitação, ignore este email.</p>
	</body>
</html>