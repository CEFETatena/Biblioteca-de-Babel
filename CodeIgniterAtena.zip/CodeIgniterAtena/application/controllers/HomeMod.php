<?php defined('BASEPATH') OR exit('No direct script access allowed');

class HomeMod extends CI_Controller {
	private $url = array();
	public function __construct() {
		parent::__construct();
		$this->url['url'] = base_url();
		$this->load->library('parser');
		$this->load->library('session');
		$this->load->library('upload');
		if(!$this->session->userdata('logado')){
				redirect("welcome/entrar");
		}
		if($this->session->userdata('perfil') == 0){
				redirect("homeUser");
		}
	}
//CARREGA AS VIEWS
	public function index()
	{
		$this->load->view('Moderador/homeMod');
	}

	public function homeMod(){
		$this->parser->parse('User/homeUser.php',$this->url);
	}

  public function logout()
	{
		redirect(base_url("Login/logout"));
	}

//GERENCIA AS PUBLICAÇÕES FEITAS PELOS USUÁRIOS
	public function gerenciarLivrosMod() {
		$user = $this->session->get_userdata();
		$user['url'] = base_url();
		$this->load->model('Conteudo');
		$user["livros"] = $this->Conteudo->pegaLivros();
		$this->parser->parse('Moderador/gerenciarLivrosMod.php',$user);
	}
	public function gerenciarDicasMod() {
		$user = $this->session->get_userdata();
		$user['url'] = base_url();
		$this->load->model('Conteudo');
		$user["dicas"] = $this->Conteudo->pegaDicas();
		$this->parser->parse('Moderador/gerenciarDicasMod.php',$user);
	}

}
